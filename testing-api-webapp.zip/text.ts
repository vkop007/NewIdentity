const STUDIO_CHAT_URL = "https://studioglobal-prod-cdn-bcd3gjghfybxg9d5.z01.azurefd.net/v1/creator/chat/guest-search-online-chat";
const DEFAULT_TEXT_MODEL = "claudeOpus48";
const DEFAULT_UPSTREAM_TIMEOUT_MS = 60_000;

export type TextGenerationInput = {
  prompt: string;
  model?: string;
  outputLanguage?: string;
  searchEngine?: string;
  reasoningLevel?: string;
};

export type TextGenerationResult = {
  type: "text";
  model: string;
  guestId: string;
  text: string;
  raw: string;
};

type NormalizedTextGenerationInput = Required<
  Pick<TextGenerationInput, "prompt" | "model" | "outputLanguage" | "searchEngine" | "reasoningLevel">
>;

type TextDeltaHandler = (delta: string) => void | Promise<void>;

function generateUUID(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }

  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0;
    const value = char === "x" ? random : (random & 0x3) | 0x8;
    return value.toString(16);
  });
}

function estimateInputTokens(prompt: string): number {
  return Math.max(1, Math.ceil(prompt.trim().length / 4));
}

function studioHeaders(guestId: string): HeadersInit {
  return {
    accept: "*/*",
    "accept-language": "en",
    "content-type": "application/json",
    referer: "https://www.studioglobal.ai/",
    "user-agent": "Mozilla/5.0",
    "x-studio-guest-id": guestId,
  };
}

function upstreamTimeoutMs(): number {
  const value = Bun.env.UPSTREAM_TIMEOUT_MS;
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : DEFAULT_UPSTREAM_TIMEOUT_MS;
}

function normalizeTextInput(input: TextGenerationInput): NormalizedTextGenerationInput {
  const prompt = input.prompt.trim();
  if (!prompt) {
    throw new Error("Prompt is required.");
  }

  return {
    prompt,
    model: input.model?.trim() || DEFAULT_TEXT_MODEL,
    outputLanguage: input.outputLanguage?.trim() || "Default",
    searchEngine: input.searchEngine?.trim() || "perplexity",
    reasoningLevel: input.reasoningLevel?.trim() || "low",
  };
}

function textPayload(input: Required<Pick<TextGenerationInput, "prompt" | "model" | "outputLanguage" | "searchEngine" | "reasoningLevel">>) {
  return {
    aiModel: input.model,
    description: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: input.prompt,
          },
        ],
        metadata: {
          routeMode: "search",
          appMode: "chat",
          chatMode: "search",
          modePreset: "fast",
          aiModel: input.model,
          chatUseCase: "general",
          searchSources: [],
          searchEngine: input.searchEngine,
          reasoningLevel: input.reasoningLevel,
          modeSwitchRouteMode: "search",
        },
        attachFiles: [],
      },
    ],
    chatContext: "chat",
    inputTokens: estimateInputTokens(input.prompt),
    outputLanguage: input.outputLanguage,
    brandVoice: "",
    searchEngine: input.searchEngine,
    reasoningLevel: input.reasoningLevel,
  };
}

async function readStream(response: Response): Promise<string> {
  const reader = response.body?.getReader();
  if (!reader) {
    return response.text();
  }

  const decoder = new TextDecoder();
  let fullResponse = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    fullResponse += decoder.decode(value, { stream: true });
  }

  fullResponse += decoder.decode();
  return fullResponse;
}

async function readStreamWithTextDeltas(response: Response, onText: TextDeltaHandler): Promise<string> {
  const reader = response.body?.getReader();
  if (!reader) {
    const raw = await response.text();
    const text = extractText(raw);
    if (text) {
      await onText(text);
    }

    return raw;
  }

  const decoder = new TextDecoder();
  let raw = "";
  let pending = "";
  let currentEvent = "";
  let emittedText = false;
  let finalText = "";

  async function processLine(line: string): Promise<void> {
    const trimmed = line.trim();
    if (!trimmed || trimmed === "[DONE]") return;

    const field = line.trimStart();
    if (field.startsWith("event:")) {
      currentEvent = field.slice(6).trim().toLowerCase();
      return;
    }

    if (field.startsWith("id:") || field.startsWith("retry:") || field.startsWith(":")) {
      return;
    }

    const isDataLine = field.startsWith("data:");
    let payload = isDataLine ? field.slice(5) : field;
    if (payload.startsWith(" ")) {
      payload = payload.slice(1);
    }
    if (!payload.trim() || payload.trim() === "[DONE]") return;

    let text = "";
    try {
      text = extractedStrings(JSON.parse(payload), { trim: false });
    } catch {
      const payloadProbe = payload.trimStart();
      if (!payloadProbe.startsWith("{") && !payloadProbe.startsWith("[") && currentEvent !== "status") {
        text = payload;
      }
    }

    if (!text) return;

    if (currentEvent === "done") {
      finalText = text;
      return;
    }

    if (currentEvent === "status") {
      return;
    }

    emittedText = true;
    await onText(text);
  }

  async function processChunk(chunk: string): Promise<void> {
    raw += chunk;
    pending += chunk;
    const lines = pending.split(/\r?\n/);
    pending = lines.pop() ?? "";

    for (const line of lines) {
      await processLine(line);
    }
  }

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    await processChunk(decoder.decode(value, { stream: true }));
  }

  await processChunk(decoder.decode());
  if (pending.trim()) {
    await processLine(pending);
  }

  if (!emittedText && finalText) {
    await onText(finalText);
  }

  return raw;
}

function collectStrings(value: unknown, output: string[]): void {
  if (typeof value === "string") {
    output.push(value);
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectStrings(item, output);
    }
    return;
  }

  if (!value || typeof value !== "object") {
    return;
  }

  const record = value as Record<string, unknown>;
  for (const key of ["text", "content", "message", "answer", "output", "delta", "token", "data"]) {
    collectStrings(record[key], output);
  }
}

function extractedStrings(value: unknown, options: { trim?: boolean } = {}): string {
  const chunks: string[] = [];
  collectStrings(value, chunks);
  const text = chunks.join("");
  return options.trim === false ? text : text.trim();
}

function extractText(raw: string): string {
  const chunks: string[] = [];
  let finalText = "";
  let currentEvent = "";

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed === "[DONE]") continue;

    const field = line.trimStart();
    if (field.startsWith("event:")) {
      currentEvent = field.slice(6).trim().toLowerCase();
      continue;
    }

    if (field.startsWith("id:") || field.startsWith("retry:") || field.startsWith(":")) {
      continue;
    }

    const isDataLine = field.startsWith("data:");
    let payload = isDataLine ? field.slice(5) : field;
    if (payload.startsWith(" ")) {
      payload = payload.slice(1);
    }
    if (!payload.trim() || payload.trim() === "[DONE]") continue;

    try {
      const parsed = JSON.parse(payload);
      const text = extractedStrings(parsed, { trim: false });
      if (!text) continue;

      if (currentEvent === "done") {
        finalText = text;
      } else if (currentEvent !== "status") {
        chunks.push(text);
      }
    } catch {
      const payloadProbe = payload.trimStart();
      if (!payloadProbe.startsWith("{") && !payloadProbe.startsWith("[") && currentEvent !== "status") {
        chunks.push(payload);
      }
    }
  }

  const text = chunks.join("").trim();
  return finalText || text || raw.trim();
}

export async function generateText(input: TextGenerationInput): Promise<TextGenerationResult> {
  const normalized = normalizeTextInput(input);
  const guestId = generateUUID();
  const response = await fetch(STUDIO_CHAT_URL, {
    method: "POST",
    headers: studioHeaders(guestId),
    signal: AbortSignal.timeout(upstreamTimeoutMs()),
    body: JSON.stringify(textPayload(normalized)),
  });

  const raw = await readStream(response);
  if (!response.ok) {
    throw new Error(`Text API error: ${response.status} ${response.statusText}${raw ? ` - ${raw}` : ""}`);
  }

  return {
    type: "text",
    model: normalized.model,
    guestId,
    text: extractText(raw),
    raw,
  };
}

export async function streamText(
  input: TextGenerationInput,
  onText: TextDeltaHandler,
): Promise<TextGenerationResult> {
  const normalized = normalizeTextInput(input);
  const guestId = generateUUID();
  const response = await fetch(STUDIO_CHAT_URL, {
    method: "POST",
    headers: studioHeaders(guestId),
    signal: AbortSignal.timeout(upstreamTimeoutMs()),
    body: JSON.stringify(textPayload(normalized)),
  });

  if (!response.ok) {
    const raw = await readStream(response);
    throw new Error(`Text API error: ${response.status} ${response.statusText}${raw ? ` - ${raw}` : ""}`);
  }

  const raw = await readStreamWithTextDeltas(response, onText);
  return {
    type: "text",
    model: normalized.model,
    guestId,
    text: extractText(raw),
    raw,
  };
}
