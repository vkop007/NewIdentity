import OpenAI from "openai";

const client = new OpenAI({
  apiKey: "dummy",
  baseURL: "https://testing-api-1780379604.azurewebsites.net/v1"
});

const chat = await client.chat.completions.create({
  model: "claudeOpus48",
  messages: [
    { role: "user", content: "Which model are you?" }
  ]
});

console.log(chat.choices[0]?.message?.content ?? "");
