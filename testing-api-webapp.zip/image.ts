const STUDIO_CHAT_URL = "https://studioglobal-prod-cdn-bcd3gjghfybxg9d5.z01.azurefd.net/v1/creator/chat/guest-search-online-chat";
const DEFAULT_IMAGE_MODEL = "gptImage2";
const DEFAULT_UPSTREAM_TIMEOUT_MS = 60_000;

export type ImageGenerationInput = {
  prompt: string;
  model?: string;
  size?: string;
  quality?: string;
  outputLanguage?: string;
  searchEngine?: string;
};

export type ImageGenerationResult = {
  type: "image";
  model: string;
  guestId: string;
  text: string;
  images: string[];
  raw: string;
};

function generateUUID(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }

  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0;
    const value = char === "x" ? random : (random & 0x3) | 0x8;
    return value.toString(16);
  });
}

function estimateInputTokens(prompt: string): number {
  return Math.max(1, Math.ceil(prompt.trim().length / 4));
}

function studioHeaders(guestId: string): HeadersInit {
  return {
    accept: "*/*",
    "accept-language": "en",
    "content-type": "application/json",
    referer: "https://www.studioglobal.ai/",
    "user-agent": "Mozilla/5.0",
    "x-studio-guest-id": guestId,
  };
}

function upstreamTimeoutMs(): number {
  const value = Bun.env.UPSTREAM_TIMEOUT_MS;
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : DEFAULT_UPSTREAM_TIMEOUT_MS;
}

function imagePayload(input: Required<Pick<ImageGenerationInput, "prompt" | "model" | "size" | "quality" | "outputLanguage" | "searchEngine">>) {
  return {
    aiModel: input.model,
    description: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: input.prompt,
          },
        ],
        metadata: {
          routeMode: "image",
          appMode: "chat",
          chatMode: "search",
          modePreset: "fast",
          aiModel: input.model,
          imageSize: input.size,
          imageQuality: input.quality,
          chatUseCase: "general",
          searchSources: [],
          searchEngine: input.searchEngine,
          modeSwitchRouteMode: "image",
        },
        attachFiles: [],
      },
    ],
    chatContext: "chat",
    inputTokens: estimateInputTokens(input.prompt),
    outputLanguage: input.outputLanguage,
    brandVoice: "",
    searchEngine: input.searchEngine,
  };
}

async function readStream(response: Response): Promise<string> {
  const reader = response.body?.getReader();
  if (!reader) {
    return response.text();
  }

  const decoder = new TextDecoder();
  let fullResponse = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    fullResponse += decoder.decode(value, { stream: true });
  }

  fullResponse += decoder.decode();
  return fullResponse;
}

function collectText(value: unknown, output: string[]): void {
  if (typeof value === "string") {
    output.push(value);
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectText(item, output);
    }
    return;
  }

  if (!value || typeof value !== "object") {
    return;
  }

  const record = value as Record<string, unknown>;
  for (const key of ["text", "content", "message", "answer", "output", "delta"]) {
    collectText(record[key], output);
  }
}

function collectImageUrls(value: unknown, output: Set<string>, parentKey = ""): void {
  if (typeof value === "string") {
    const isImageKey = /image|url|src|asset/i.test(parentKey);
    const looksLikeImage = /^data:image\//i.test(value) || /\.(png|jpe?g|webp|gif)(\?|#|$)/i.test(value);
    if ((isImageKey || looksLikeImage) && /^(https?:\/\/|data:image\/)/i.test(value)) {
      output.add(value);
    }
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectImageUrls(item, output, parentKey);
    }
    return;
  }

  if (!value || typeof value !== "object") {
    return;
  }

  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    collectImageUrls(child, output, key);
  }
}

function parseStreamPayloads(raw: string): unknown[] {
  const payloads: unknown[] = [];

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed === "[DONE]") continue;

    const payload = trimmed.startsWith("data:")
      ? trimmed.slice(5).trim()
      : trimmed;
    if (!payload || payload === "[DONE]") continue;

    try {
      payloads.push(JSON.parse(payload));
    } catch {
      // Keep non-JSON chunks in raw; callers still receive the complete response.
    }
  }

  return payloads;
}

function extractImageResult(raw: string): Pick<ImageGenerationResult, "text" | "images"> {
  const textParts: string[] = [];
  const imageUrls = new Set<string>();
  const payloads = parseStreamPayloads(raw);

  for (const payload of payloads) {
    collectText(payload, textParts);
    collectImageUrls(payload, imageUrls);
  }

  for (const match of raw.matchAll(/https?:\/\/[^\s"'<>\\]+?\.(?:png|jpe?g|webp|gif)(?:[?#][^\s"'<>\\]*)?/gi)) {
    imageUrls.add(match[0]);
  }

  return {
    text: textParts.join("").trim() || raw.trim(),
    images: [...imageUrls],
  };
}

export async function generateImage(input: ImageGenerationInput): Promise<ImageGenerationResult> {
  const prompt = input.prompt.trim();
  if (!prompt) {
    throw new Error("Prompt is required.");
  }

  const model = input.model?.trim() || DEFAULT_IMAGE_MODEL;
  const guestId = generateUUID();
  const response = await fetch(STUDIO_CHAT_URL, {
    method: "POST",
    headers: studioHeaders(guestId),
    signal: AbortSignal.timeout(upstreamTimeoutMs()),
    body: JSON.stringify(imagePayload({
      prompt,
      model,
      size: input.size?.trim() || "1024x1024",
      quality: input.quality?.trim() || "low",
      outputLanguage: input.outputLanguage?.trim() || "Default",
      searchEngine: input.searchEngine?.trim() || "perplexity",
    })),
  });

  const raw = await readStream(response);
  if (!response.ok) {
    throw new Error(`Image API error: ${response.status} ${response.statusText}${raw ? ` - ${raw}` : ""}`);
  }

  const parsed = extractImageResult(raw);
  return {
    type: "image",
    model,
    guestId,
    ...parsed,
    raw,
  };
}
