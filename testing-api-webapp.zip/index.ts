import { generateImage, type ImageGenerationInput } from "./image.ts";
import { generateText, streamText, type TextGenerationInput } from "./text.ts";

type JsonBody = Record<string, unknown>;
type JsonRecord = Record<string, unknown>;
type ToolSpec = {
  name: string;
  description?: string;
  inputSchema: unknown;
};
type ToolChoice = {
  mode: "auto" | "none" | "required";
  name?: string;
};
type ToolCall = {
  id: string;
  name: string;
  arguments: JsonRecord;
};
type AssistantPlan =
  | { type: "text"; content: string }
  | { type: "tool_calls"; toolCalls: ToolCall[] };

const DEFAULT_PORT = 8787;
const TEXT_MODEL_ID = "claudeOpus48";
const IMAGE_MODEL_ID = "gptImage2";
const port = readPort(Bun.env.PORT ?? Bun.env.WEBSITES_PORT, DEFAULT_PORT);
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Api-Key,Anthropic-Version,Anthropic-Beta,OpenAI-Organization,OpenAI-Project",
};

function readPort(value: string | undefined, fallback: number): number {
  if (!value) {
    return fallback;
  }

  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json; charset=utf-8",
    },
  });
}

function sseHeaders(): HeadersInit {
  return {
    ...corsHeaders,
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    "X-Accel-Buffering": "no",
    Connection: "keep-alive",
  };
}

function sseResponse(events: string[]): Response {
  return new Response(events.join(""), {
    status: 200,
    headers: sseHeaders(),
  });
}

function sseStreamResponse(body: ReadableStream<Uint8Array>): Response {
  return new Response(body, {
    status: 200,
    headers: sseHeaders(),
  });
}

function errorResponse(error: unknown, status = 500): Response {
  const message = error instanceof Error ? error.message : "Unexpected server error.";
  return jsonResponse({ error: message }, status);
}

function openAIErrorResponse(error: unknown, status = 500): Response {
  const message = error instanceof Error ? error.message : "Unexpected server error.";
  return jsonResponse({
    error: {
      message,
      type: status >= 500 ? "server_error" : "invalid_request_error",
      param: null,
      code: null,
    },
  }, status);
}

async function readJson(request: Request): Promise<JsonBody> {
  if (request.method === "GET") {
    return {};
  }

  const contentType = request.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) {
    throw new RequestError("Request body must be JSON.", 415);
  }

  try {
    const body = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      throw new RequestError("JSON body must be an object.", 400);
    }

    return body as JsonBody;
  } catch (error) {
    if (error instanceof RequestError) {
      throw error;
    }

    throw new RequestError("Invalid JSON body.", 400);
  }
}

function readString(body: JsonBody, url: URL, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = body[key] ?? url.searchParams.get(key);
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }

  return undefined;
}

function textInput(body: JsonBody, url: URL): TextGenerationInput {
  const prompt = readString(body, url, ["prompt", "text", "message", "input", "q"]);
  if (!prompt) {
    throw new RequestError("Missing prompt. Send { \"prompt\": \"...\" }.", 400);
  }

  return {
    prompt,
    model: readString(body, url, ["model"]),
    outputLanguage: readString(body, url, ["outputLanguage", "output_language"]),
    searchEngine: readString(body, url, ["searchEngine", "search_engine"]),
    reasoningLevel: readString(body, url, ["reasoningLevel", "reasoning_level"]),
  };
}

function imageInput(body: JsonBody, url: URL): ImageGenerationInput {
  const prompt = readString(body, url, ["prompt", "text", "message", "input", "q"]);
  if (!prompt) {
    throw new RequestError("Missing prompt. Send { \"prompt\": \"...\" }.", 400);
  }

  return {
    prompt,
    model: readString(body, url, ["model"]),
    size: readString(body, url, ["size", "imageSize", "image_size"]),
    quality: readString(body, url, ["quality", "imageQuality", "image_quality"]),
    outputLanguage: readString(body, url, ["outputLanguage", "output_language"]),
    searchEngine: readString(body, url, ["searchEngine", "search_engine"]),
  };
}

function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.trim().length / 4));
}

function openAIId(prefix: string): string {
  const id = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `${prefix}-${id.replace(/-/g, "")}`;
}

function compactId(prefix: string): string {
  const id = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `${prefix}_${id.replace(/-/g, "")}`;
}

function isRecord(value: unknown): value is JsonRecord {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function jsonString(value: unknown): string {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function readTextField(record: JsonRecord, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = record[key];
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }

  return undefined;
}

function readMessageText(content: unknown): string {
  if (typeof content === "string") {
    return content;
  }

  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (typeof part === "string") return part;
        if (!part || typeof part !== "object") return "";

        const record = part as JsonRecord;
        if (record.type === "tool_result") {
          const toolUseId = typeof record.tool_use_id === "string" ? record.tool_use_id : "unknown";
          return `tool_result ${toolUseId}: ${readMessageText(record.content)}`;
        }

        if (record.type === "tool_use") {
          const name = typeof record.name === "string" ? record.name : "unknown";
          return `tool_use ${name}: ${jsonString(record.input ?? {})}`;
        }

        if (typeof record.text === "string") return record.text;
        if (typeof record.content === "string") return record.content;
        if (typeof record.input_text === "string") return record.input_text;
        return "";
      })
      .filter(Boolean)
      .join("\n");
  }

  return "";
}

function readToolArguments(value: unknown): JsonRecord {
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      return isRecord(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }

  return isRecord(value) ? value : {};
}

function readArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function normalizeInputSchema(value: unknown): unknown {
  return isRecord(value) ? value : { type: "object", properties: {} };
}

function normalizeOpenAITool(value: unknown): ToolSpec | undefined {
  if (!isRecord(value)) return undefined;

  const functionSpec = isRecord(value.function) ? value.function : value;
  const name = typeof functionSpec.name === "string" ? functionSpec.name.trim() : "";
  if (!name) return undefined;

  return {
    name,
    description: typeof functionSpec.description === "string" ? functionSpec.description : undefined,
    inputSchema: normalizeInputSchema(functionSpec.parameters),
  };
}

function normalizeAnthropicTool(value: unknown): ToolSpec | undefined {
  if (!isRecord(value)) return undefined;

  const name = typeof value.name === "string" ? value.name.trim() : "";
  if (!name) return undefined;

  return {
    name,
    description: typeof value.description === "string" ? value.description : undefined,
    inputSchema: normalizeInputSchema(value.input_schema ?? value.parameters),
  };
}

function normalizeOpenAITools(body: JsonBody): ToolSpec[] {
  const tools: ToolSpec[] = [];

  if (Array.isArray(body.tools)) {
    for (const tool of body.tools) {
      const normalized = normalizeOpenAITool(tool);
      if (normalized) tools.push(normalized);
    }
  }

  if (Array.isArray(body.functions)) {
    for (const fn of body.functions) {
      const normalized = normalizeOpenAITool(fn);
      if (normalized) tools.push(normalized);
    }
  }

  return tools;
}

function normalizeAnthropicTools(body: JsonBody): ToolSpec[] {
  if (!Array.isArray(body.tools)) return [];

  return body.tools
    .map((tool) => normalizeAnthropicTool(tool))
    .filter((tool): tool is ToolSpec => Boolean(tool));
}

function openAIToolChoice(body: JsonBody): ToolChoice {
  const choice = body.tool_choice ?? body.function_call;
  if (choice === "none") return { mode: "none" };
  if (choice === "required") return { mode: "required" };
  if (choice === "auto" || choice === undefined) return { mode: "auto" };

  if (isRecord(choice)) {
    const functionSpec = isRecord(choice.function) ? choice.function : choice;
    const name = typeof functionSpec.name === "string" ? functionSpec.name.trim() : "";
    if (name) return { mode: "required", name };
  }

  return { mode: "auto" };
}

function anthropicToolChoice(body: JsonBody): ToolChoice {
  const choice = body.tool_choice;
  if (choice === undefined) return { mode: "auto" };
  if (choice === "none") return { mode: "none" };

  if (isRecord(choice)) {
    const type = typeof choice.type === "string" ? choice.type : "";
    if (type === "none") return { mode: "none" };
    if (type === "any") return { mode: "required" };
    if (type === "tool") {
      const name = typeof choice.name === "string" ? choice.name.trim() : "";
      return name ? { mode: "required", name } : { mode: "required" };
    }
  }

  return { mode: "auto" };
}

function toolPrompt(basePrompt: string, tools: ToolSpec[], choice: ToolChoice): string {
  const allowedToolText = tools
    .map((tool) => `- ${tool.name}: ${tool.description || "No description"}\n  input_schema: ${jsonString(tool.inputSchema)}`)
    .join("\n");
  const choiceText = choice.name
    ? `You must call the tool named "${choice.name}" when a tool call is needed.`
    : choice.mode === "required"
      ? "You must call at least one tool."
      : "Call tools only when they are needed. Otherwise answer normally.";
  const responseRules = choice.mode === "required"
    ? [
      "Return exactly one JSON object and no markdown.",
      'For tool calls, use: {"type":"tool_calls","tool_calls":[{"name":"tool_name","arguments":{}}]}',
    ]
    : [
      'When a tool is needed, return exactly one JSON object and no markdown: {"type":"tool_calls","tool_calls":[{"name":"tool_name","arguments":{}}]}',
      "If no tool is needed, answer normally as assistant text. Do not wrap final answers in JSON.",
    ];

  return [
    "You are behind an API gateway that supports structured tool calling.",
    "You are not executing tools yourself. The API client will execute any tool calls you return.",
    "Never say you lack file access, terminal access, browser access, or editing access when a matching tool is listed.",
    "For code work, inspect files with Read, LS, Glob, or Grep before editing. After file contents are available, use Edit, MultiEdit, Write, or Bash when appropriate.",
    "Conversation:",
    basePrompt,
    "Available tools:",
    allowedToolText,
    choiceText,
    ...responseRules,
    "Only use tool names from the available tools list. Tool arguments must be valid JSON objects.",
  ].join("\n\n");
}

function scanJsonBlocks(text: string): string[] {
  const blocks: string[] = [];
  let start = -1;
  let depth = 0;
  let inString = false;
  let escape = false;
  const stack: string[] = [];

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];

    if (inString) {
      if (escape) {
        escape = false;
      } else if (char === "\\") {
        escape = true;
      } else if (char === "\"") {
        inString = false;
      }
      continue;
    }

    if (char === "\"") {
      inString = true;
      continue;
    }

    if (char === "{" || char === "[") {
      if (depth === 0) start = index;
      depth += 1;
      stack.push(char === "{" ? "}" : "]");
      continue;
    }

    if ((char === "}" || char === "]") && depth > 0) {
      const expected = stack.pop();
      if (char !== expected) {
        start = -1;
        depth = 0;
        stack.length = 0;
        continue;
      }

      depth -= 1;
      if (depth === 0 && start >= 0) {
        blocks.push(text.slice(start, index + 1));
        start = -1;
      }
    }
  }

  return blocks;
}

function parseJsonValue(candidate: string): unknown | undefined {
  try {
    return JSON.parse(candidate);
  } catch {
    return undefined;
  }
}

function parseJsonCandidates(text: string): unknown[] {
  const trimmed = text.trim();
  const candidates = new Set<string>();
  if (trimmed) candidates.add(trimmed);

  for (const match of trimmed.matchAll(/```(?:json)?\s*([\s\S]*?)```/gi)) {
    const fenced = match[1]?.trim();
    if (fenced) candidates.add(fenced);
  }

  for (const block of scanJsonBlocks(trimmed)) {
    candidates.add(block);
  }

  const parsed: unknown[] = [];
  for (const candidate of candidates) {
    const value = parseJsonValue(candidate);
    if (value !== undefined) {
      parsed.push(value);
    }
  }

  return parsed;
}

function toolCallsFromParsed(parsed: unknown, tools: ToolSpec[]): ToolCall[] {
  if (!isRecord(parsed)) return [];

  const allowed = new Set(tools.map((tool) => tool.name));
  const rawCalls = Array.isArray(parsed.tool_calls)
    ? parsed.tool_calls
    : Array.isArray(parsed.tools)
      ? parsed.tools
      : Array.isArray(parsed.calls)
        ? parsed.calls
        : [parsed];
  const calls: ToolCall[] = [];

  for (const rawCall of rawCalls) {
    if (!isRecord(rawCall)) continue;

    const functionSpec = isRecord(rawCall.function) ? rawCall.function : rawCall;
    const name = readTextField(functionSpec, ["name", "tool_name", "tool"]);
    if (!name || (allowed.size > 0 && !allowed.has(name))) continue;

    const args = readToolArguments(
      functionSpec.arguments ?? functionSpec.input ?? functionSpec.args ?? functionSpec.parameters,
    );
    calls.push({
      id: typeof rawCall.id === "string" && rawCall.id.trim() ? rawCall.id.trim() : compactId("call"),
      name,
      arguments: args,
    });
  }

  return calls;
}

function latestUserText(contextText: string): string {
  const matches = Array.from(contextText.matchAll(/(?:^|\n)user:\s*([\s\S]*?)(?=\n(?:system|assistant|user|tool|tool_result|tool_use):|$)/gi));
  const last = matches.at(-1)?.[1];
  return (last ?? contextText).trim();
}

function extractCwd(contextText: string): string | undefined {
  const cwdTag = contextText.match(/<cwd>\s*([^<\s]+)\s*<\/cwd>/i)?.[1];
  if (cwdTag) return cwdTag;

  const cwdLine = contextText.match(/(?:cwd|current working directory|working directory)\s*[:=]\s*([~/][^\s"'<>]+)/i)?.[1];
  return cwdLine;
}

function extractFilePath(contextText: string): string | undefined {
  const pathMatches = Array.from(contextText.matchAll(/(?:^|[\s"'`])((?:\/|~\/)[^\s"'`<>]+?\.[A-Za-z0-9][A-Za-z0-9._-]*)(?=[\s"'`),.:;!?]|$)/g))
    .map((match) => match[1])
    .filter(Boolean);

  return pathMatches.at(-1);
}

function toolProperties(tool: ToolSpec): JsonRecord {
  const schema = isRecord(tool.inputSchema) ? tool.inputSchema : {};
  return isRecord(schema.properties) ? schema.properties : {};
}

function toolRequired(tool: ToolSpec): string[] {
  const schema = isRecord(tool.inputSchema) ? tool.inputSchema : {};
  return readArray(schema.required).filter((value): value is string => typeof value === "string");
}

function schemaType(schema: unknown): string {
  if (!isRecord(schema)) return "";
  const type = schema.type;
  return typeof type === "string" ? type : "";
}

function findTool(tools: ToolSpec[], names: string[]): ToolSpec | undefined {
  for (const name of names) {
    const exact = tools.find((tool) => tool.name === name);
    if (exact) return exact;

    const lower = name.toLowerCase();
    const insensitive = tools.find((tool) => tool.name.toLowerCase() === lower);
    if (insensitive) return insensitive;
  }

  return undefined;
}

function defaultValueForProperty(
  key: string,
  schema: unknown,
  contextText: string,
): unknown {
  const lowerKey = key.toLowerCase();
  const type = schemaType(schema);
  const filePath = extractFilePath(contextText);
  const cwd = extractCwd(contextText);

  if (isRecord(schema) && schema.default !== undefined) {
    return schema.default;
  }

  if (lowerKey === "file_path" || lowerKey === "filepath" || lowerKey === "file") {
    return filePath ?? cwd ?? ".";
  }

  if (lowerKey === "path" || lowerKey === "cwd") {
    return cwd ?? filePath ?? ".";
  }

  if (lowerKey === "pattern") {
    return filePath ? filePath.split("/").at(-1) ?? "*" : "*";
  }

  if (lowerKey === "command") {
    return cwd ? `ls -la ${JSON.stringify(cwd)}` : "pwd";
  }

  if (lowerKey === "description") {
    return "Inspect project files";
  }

  if (lowerKey === "limit" || lowerKey === "head_limit") {
    return 200;
  }

  if (lowerKey === "offset") {
    return 0;
  }

  if (type === "number" || type === "integer") return 0;
  if (type === "boolean") return false;
  if (type === "array") return [];
  if (type === "object") return {};
  return "";
}

function defaultToolArguments(tool: ToolSpec, contextText: string): JsonRecord {
  const properties = toolProperties(tool);
  const required = toolRequired(tool);
  const args: JsonRecord = {};

  for (const key of required) {
    args[key] = defaultValueForProperty(key, properties[key], contextText);
  }

  const filePath = extractFilePath(contextText);
  if (filePath && "file_path" in properties && args.file_path === undefined) {
    args.file_path = filePath;
  }

  const cwd = extractCwd(contextText);
  if (cwd && "path" in properties && args.path === undefined) {
    args.path = cwd;
  }

  if ("limit" in properties && args.limit === undefined) {
    args.limit = 200;
  }

  if ("offset" in properties && args.offset === undefined) {
    args.offset = 0;
  }

  return args;
}

function shouldFallbackToTool(modelText: string, choice: ToolChoice, contextText: string): boolean {
  if (choice.mode === "required") return true;

  const text = `${latestUserText(contextText)}\n${modelText}`.toLowerCase();
  const wantsAction = /\b(implement|fix|edit|modify|update|change|add|create|write|save|apply|continue|run|test|check|inspect|open|read|verify)\b/.test(text);
  const refusal = /\b(don't|do not|cannot|can't|unable|no)\b[\s\S]{0,80}\b(access|edit|modify|read|write|execute|file|files|project|workspace|tool|tools)\b/.test(text)
    || /\bsend (me )?(the )?(file|files|code|project)\b/.test(text);

  return wantsAction || refusal;
}

function fallbackToolPlan(modelText: string, tools: ToolSpec[], choice: ToolChoice, contextText: string): AssistantPlan | undefined {
  if (tools.length === 0 || choice.mode === "none" || !shouldFallbackToTool(modelText, choice, contextText)) {
    return undefined;
  }

  const latest = latestUserText(contextText).toLowerCase();
  const forced = choice.name ? findTool(tools, [choice.name]) : undefined;
  const hasFilePath = Boolean(extractFilePath(contextText));
  const requestedShell = /\b(run|test|build|execute|command|terminal|shell|bash)\b/.test(latest);
  const preferred = forced
    ?? (requestedShell ? findTool(tools, ["Bash", "Shell"]) : undefined)
    ?? (hasFilePath ? findTool(tools, ["Read", "View"]) : undefined)
    ?? findTool(tools, ["LS", "List", "Glob", "Grep", "Search", "Read", "Bash"]);

  if (!preferred) return undefined;

  return {
    type: "tool_calls",
    toolCalls: [
      {
        id: compactId("call"),
        name: preferred.name,
        arguments: defaultToolArguments(preferred, contextText),
      },
    ],
  };
}

function assistantPlan(text: string, tools: ToolSpec[], choice: ToolChoice, contextText = ""): AssistantPlan {
  const parsedCandidates = parseJsonCandidates(text);
  for (const parsed of parsedCandidates) {
    const toolCalls = toolCallsFromParsed(parsed, tools);
    if (toolCalls.length > 0) {
      return { type: "tool_calls", toolCalls };
    }
  }

  for (const parsed of parsedCandidates) {
    if (!isRecord(parsed)) continue;
    const content = readTextField(parsed, ["content", "text", "answer", "message"]);
    if (content) {
      return { type: "text", content };
    }
  }

  const fallback = fallbackToolPlan(text, tools, choice, contextText);
  if (fallback) return fallback;

  const forcedTool = choice.name && tools.some((tool) => tool.name === choice.name)
    ? choice.name
    : undefined;
  if (forcedTool && choice.mode === "required") {
    return {
      type: "tool_calls",
      toolCalls: [{ id: compactId("call"), name: forcedTool, arguments: {} }],
    };
  }

  return { type: "text", content: text.trim() };
}

function serializeMessage(message: unknown): string {
  if (!isRecord(message)) return "";

  const role = typeof message.role === "string" ? message.role : "user";
  const parts: string[] = [];
  const content = readMessageText(message.content).trim();
  if (content) parts.push(content);

  if (Array.isArray(message.tool_calls)) {
    parts.push(`tool_calls: ${jsonString(message.tool_calls)}`);
  }

  if (typeof message.tool_call_id === "string") {
    parts.push(`tool_call_id: ${message.tool_call_id}`);
  }

  if (typeof message.name === "string") {
    parts.push(`name: ${message.name}`);
  }

  return parts.length > 0 ? `${role}: ${parts.join("\n")}` : "";
}

function serializeMessages(messages: unknown): string {
  if (!Array.isArray(messages) || messages.length === 0) {
    throw new RequestError("Missing messages. Send messages array.", 400);
  }

  return messages
    .map((message) => serializeMessage(message))
    .filter(Boolean)
    .join("\n");
}

function openAIChatInput(body: JsonBody): TextGenerationInput {
  const prompt = serializeMessages(body.messages);
  if (!prompt) {
    throw new RequestError("Messages must contain text content.", 400);
  }

  return {
    prompt,
    model: typeof body.model === "string" && body.model.trim() ? body.model.trim() : TEXT_MODEL_ID,
  };
}

function openAIImageInput(body: JsonBody): ImageGenerationInput {
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  if (!prompt) {
    throw new RequestError("Missing prompt. Send { \"prompt\": \"...\" }.", 400);
  }

  return {
    prompt,
    model: typeof body.model === "string" && body.model.trim() ? body.model.trim() : IMAGE_MODEL_ID,
    size: typeof body.size === "string" && body.size.trim() ? body.size.trim() : undefined,
    quality: typeof body.quality === "string" && body.quality.trim() ? body.quality.trim() : undefined,
  };
}

async function openAIChatResponse(body: JsonBody): Promise<Response> {
  const tools = normalizeOpenAITools(body);
  const toolChoice = openAIToolChoice(body);
  const baseInput = openAIChatInput(body);
  const input = tools.length > 0 && toolChoice.mode !== "none"
    ? { ...baseInput, prompt: toolPrompt(baseInput.prompt, tools, toolChoice) }
    : baseInput;
  const result = await generateText(input);
  const plan = tools.length > 0 && toolChoice.mode !== "none"
    ? assistantPlan(result.text, tools, toolChoice, baseInput.prompt)
    : { type: "text" as const, content: result.text };
  const created = Math.floor(Date.now() / 1000);
  const id = openAIId("chatcmpl");
  const model = input.model || result.model;
  const promptTokens = estimateTokens(input.prompt);
  const completionText = plan.type === "text"
    ? plan.content
    : plan.toolCalls.map((call) => `${call.name} ${jsonString(call.arguments)}`).join("\n");
  const completionTokens = estimateTokens(completionText);

  if (body.stream === true) {
    const roleChunk = {
      id,
      object: "chat.completion.chunk",
      created,
      model,
      choices: [
        {
          index: 0,
          delta: {
            role: "assistant",
          },
          finish_reason: null,
        },
      ],
    };
    const contentChunk = plan.type === "tool_calls"
      ? {
        id,
        object: "chat.completion.chunk",
        created,
        model,
        choices: [
          {
            index: 0,
            delta: {
              tool_calls: plan.toolCalls.map((call, index) => ({
                index,
                id: call.id,
                type: "function",
                function: {
                  name: call.name,
                  arguments: jsonString(call.arguments),
                },
              })),
            },
            finish_reason: null,
          },
        ],
      }
      : {
        id,
        object: "chat.completion.chunk",
        created,
        model,
        choices: [
          {
            index: 0,
            delta: {
              content: plan.content,
            },
            finish_reason: null,
          },
        ],
      };
    const doneChunk = {
      id,
      object: "chat.completion.chunk",
      created,
      model,
      choices: [
        {
          index: 0,
          delta: {},
          finish_reason: plan.type === "tool_calls" ? "tool_calls" : "stop",
        },
      ],
    };

    return sseResponse([
      `data: ${JSON.stringify(roleChunk)}\n\n`,
      `data: ${JSON.stringify(contentChunk)}\n\n`,
      `data: ${JSON.stringify(doneChunk)}\n\n`,
      "data: [DONE]\n\n",
    ]);
  }

  return jsonResponse({
    id,
    object: "chat.completion",
    created,
    model,
    choices: [
      {
        index: 0,
        message: plan.type === "tool_calls"
          ? {
            role: "assistant",
            content: null,
            tool_calls: plan.toolCalls.map((call) => ({
              id: call.id,
              type: "function",
              function: {
                name: call.name,
                arguments: jsonString(call.arguments),
              },
            })),
          }
          : {
            role: "assistant",
            content: plan.content,
          },
        finish_reason: plan.type === "tool_calls" ? "tool_calls" : "stop",
      },
    ],
    usage: {
      prompt_tokens: promptTokens,
      completion_tokens: completionTokens,
      total_tokens: promptTokens + completionTokens,
    },
  });
}

function imageDataItem(image: string, responseFormat: string | undefined, revisedPrompt: string) {
  if (responseFormat === "b64_json" && image.startsWith("data:image/")) {
    return {
      b64_json: image.split(",", 2)[1] ?? image,
      revised_prompt: revisedPrompt,
    };
  }

  return {
    url: image,
    revised_prompt: revisedPrompt,
  };
}

async function openAIImageResponse(body: JsonBody): Promise<Response> {
  const input = openAIImageInput(body);
  const result = await generateImage(input);
  const created = Math.floor(Date.now() / 1000);
  const responseFormat = typeof body.response_format === "string" ? body.response_format : undefined;

  return jsonResponse({
    created,
    data: result.images.map((image) => imageDataItem(image, responseFormat, input.prompt)),
  });
}

function openAIModelsResponse(): Response {
  const created = Math.floor(Date.now() / 1000);
  const createdAt = new Date(created * 1000).toISOString();
  return jsonResponse({
    object: "list",
    data: [
      {
        id: TEXT_MODEL_ID,
        object: "model",
        type: "model",
        created,
        created_at: createdAt,
        owned_by: "testing-api",
        display_name: "Claude Opus 4.8",
        capabilities: {
          chat_completions: true,
          messages: true,
          tools: true,
          streaming: true,
        },
      },
      {
        id: IMAGE_MODEL_ID,
        object: "model",
        type: "model",
        created,
        created_at: createdAt,
        owned_by: "testing-api",
        display_name: "GPT Image 5.5",
        capabilities: {
          image_generations: true,
        },
      },
    ],
    first_id: TEXT_MODEL_ID,
    last_id: IMAGE_MODEL_ID,
    has_more: false,
  });
}

function anthropicSystemText(system: unknown): string {
  if (typeof system === "string") {
    return system.trim();
  }

  return readMessageText(system).trim();
}

function anthropicConversationPrompt(body: JsonBody): string {
  const parts: string[] = [];
  const system = anthropicSystemText(body.system);
  if (system) {
    parts.push(`system: ${system}`);
  }

  const messages = serializeMessages(body.messages);
  if (messages) {
    parts.push(messages);
  }

  const prompt = parts.join("\n");
  if (!prompt) {
    throw new RequestError("Messages must contain text content.", 400);
  }

  return prompt;
}

function anthropicMessageInput(body: JsonBody): {
  input: TextGenerationInput;
  tools: ToolSpec[];
  toolChoice: ToolChoice;
  basePrompt: string;
} {
  const tools = normalizeAnthropicTools(body);
  const toolChoice = anthropicToolChoice(body);
  const basePrompt = anthropicConversationPrompt(body);
  const prompt = tools.length > 0 && toolChoice.mode !== "none"
    ? toolPrompt(basePrompt, tools, toolChoice)
    : basePrompt;

  return {
    input: {
      prompt,
      model: typeof body.model === "string" && body.model.trim() ? body.model.trim() : TEXT_MODEL_ID,
    },
    tools,
    toolChoice,
    basePrompt,
  };
}

function anthropicContent(plan: AssistantPlan): unknown[] {
  if (plan.type === "tool_calls") {
    return plan.toolCalls.map((call) => ({
      type: "tool_use",
      id: call.id.startsWith("toolu_") ? call.id : compactId("toolu"),
      name: call.name,
      input: call.arguments,
    }));
  }

  return [{ type: "text", text: plan.content }];
}

function anthropicMessageObject(
  id: string,
  model: string,
  plan: AssistantPlan,
  inputTokens: number,
  outputTokens: number,
): JsonRecord {
  return {
    id,
    type: "message",
    role: "assistant",
    model,
    content: anthropicContent(plan),
    stop_reason: plan.type === "tool_calls" ? "tool_use" : "end_turn",
    stop_sequence: null,
    usage: {
      input_tokens: inputTokens,
      output_tokens: outputTokens,
    },
  };
}

function anthropicSse(event: string, data: unknown): string {
  return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
}

type AnthropicEventSender = (event: string, data: unknown) => void;

function planOutputText(plan: AssistantPlan): string {
  return plan.type === "text"
    ? plan.content
    : plan.toolCalls.map((call) => `${call.name} ${jsonString(call.arguments)}`).join("\n");
}

function sendAnthropicMessageStart(
  send: AnthropicEventSender,
  id: string,
  model: string,
  inputTokens: number,
): void {
  send("message_start", {
    type: "message_start",
    message: {
      id,
      type: "message",
      role: "assistant",
      model,
      content: [],
      stop_reason: null,
      stop_sequence: null,
      usage: {
        input_tokens: inputTokens,
        output_tokens: 0,
      },
    },
  });
}

function sendAnthropicTextStart(send: AnthropicEventSender, index = 0): void {
  send("content_block_start", {
    type: "content_block_start",
    index,
    content_block: {
      type: "text",
      text: "",
    },
  });
}

function sendAnthropicTextDelta(send: AnthropicEventSender, text: string, index = 0): void {
  send("content_block_delta", {
    type: "content_block_delta",
    index,
    delta: {
      type: "text_delta",
      text,
    },
  });
}

function sendAnthropicTextStop(send: AnthropicEventSender, index = 0): void {
  send("content_block_stop", {
    type: "content_block_stop",
    index,
  });
}

function sendAnthropicPlanContent(send: AnthropicEventSender, plan: AssistantPlan): void {
  if (plan.type === "tool_calls") {
    plan.toolCalls.forEach((call, index) => {
      const toolUseId = call.id.startsWith("toolu_") ? call.id : compactId("toolu");
      send("content_block_start", {
        type: "content_block_start",
        index,
        content_block: {
          type: "tool_use",
          id: toolUseId,
          name: call.name,
          input: {},
        },
      });
      send("content_block_delta", {
        type: "content_block_delta",
        index,
        delta: {
          type: "input_json_delta",
          partial_json: jsonString(call.arguments),
        },
      });
      send("content_block_stop", {
        type: "content_block_stop",
        index,
      });
    });
    return;
  }

  sendAnthropicTextStart(send);
  if (plan.content) {
    sendAnthropicTextDelta(send, plan.content);
  }
  sendAnthropicTextStop(send);
}

function sendAnthropicPlanStop(
  send: AnthropicEventSender,
  plan: AssistantPlan,
  outputTokens: number,
): void {
  send("message_delta", {
    type: "message_delta",
    delta: {
      stop_reason: plan.type === "tool_calls" ? "tool_use" : "end_turn",
      stop_sequence: null,
    },
    usage: {
      output_tokens: outputTokens,
    },
  });
  send("message_stop", { type: "message_stop" });
}

function sendAnthropicStreamError(send: AnthropicEventSender, error: unknown): void {
  const message = error instanceof Error ? error.message : "Unexpected server error.";
  send("error", {
    type: "error",
    error: {
      type: "api_error",
      message,
    },
  });
}

function anthropicStreamResponse(run: (send: AnthropicEventSender) => Promise<void>): Response {
  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send: AnthropicEventSender = (event, data) => {
        controller.enqueue(encoder.encode(anthropicSse(event, data)));
      };

      try {
        await run(send);
      } catch (error) {
        sendAnthropicStreamError(send, error);
      } finally {
        controller.close();
      }
    },
  });

  return sseStreamResponse(stream);
}

function startAnthropicPings(send: AnthropicEventSender): ReturnType<typeof setInterval> {
  return setInterval(() => {
    send("ping", { type: "ping" });
  }, 5_000);
}

function anthropicLiveTextStream(
  id: string,
  model: string,
  input: TextGenerationInput,
  inputTokens: number,
): Response {
  return anthropicStreamResponse(async (send) => {
    sendAnthropicMessageStart(send, id, model, inputTokens);
    sendAnthropicTextStart(send);

    let sentText = false;
    const pings = startAnthropicPings(send);
    try {
      const result = await streamText(input, (delta) => {
        if (!delta) return;
        sentText = true;
        sendAnthropicTextDelta(send, delta);
      });
      const outputTokens = estimateTokens(result.text);
      if (!sentText && result.text) {
        sendAnthropicTextDelta(send, result.text);
      }
      sendAnthropicTextStop(send);
      sendAnthropicPlanStop(send, { type: "text", content: result.text }, outputTokens);
    } finally {
      clearInterval(pings);
    }
  });
}

function anthropicBufferedPlanStream(
  id: string,
  model: string,
  input: TextGenerationInput,
  tools: ToolSpec[],
  toolChoice: ToolChoice,
  inputTokens: number,
  contextText: string,
): Response {
  return anthropicStreamResponse(async (send) => {
    sendAnthropicMessageStart(send, id, model, inputTokens);

    const pings = startAnthropicPings(send);
    try {
      const result = await generateText(input);
      const plan = tools.length > 0 && toolChoice.mode !== "none"
        ? assistantPlan(result.text, tools, toolChoice, contextText)
        : { type: "text" as const, content: result.text };
      const outputTokens = estimateTokens(planOutputText(plan));
      sendAnthropicPlanContent(send, plan);
      sendAnthropicPlanStop(send, plan, outputTokens);
    } finally {
      clearInterval(pings);
    }
  });
}

async function anthropicMessageResponse(body: JsonBody): Promise<Response> {
  const { input, tools, toolChoice, basePrompt } = anthropicMessageInput(body);
  const id = compactId("msg");
  const model = input.model || TEXT_MODEL_ID;
  const inputTokens = estimateTokens(input.prompt);

  if (body.stream === true) {
    if (tools.length > 0 && toolChoice.mode !== "none") {
      return anthropicBufferedPlanStream(id, model, input, tools, toolChoice, inputTokens, basePrompt);
    }

    return anthropicLiveTextStream(id, model, input, inputTokens);
  }

  const result = await generateText(input);
  const plan = tools.length > 0 && toolChoice.mode !== "none"
    ? assistantPlan(result.text, tools, toolChoice, basePrompt)
    : { type: "text" as const, content: result.text };
  const completionText = planOutputText(plan);
  const outputTokens = estimateTokens(completionText);

  return jsonResponse(anthropicMessageObject(id, model, plan, inputTokens, outputTokens));
}

function anthropicTokenCountResponse(body: JsonBody): Response {
  const tools = normalizeAnthropicTools(body);
  const toolChoice = anthropicToolChoice(body);
  const basePrompt = anthropicConversationPrompt(body);
  const prompt = tools.length > 0 && toolChoice.mode !== "none"
    ? toolPrompt(basePrompt, tools, toolChoice)
    : basePrompt;

  return jsonResponse({ input_tokens: estimateTokens(prompt) });
}

class RequestError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
    this.name = "RequestError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

function isRequestError(error: unknown): error is RequestError {
  return error instanceof RequestError || (
    Boolean(error) &&
    typeof error === "object" &&
    typeof (error as { status?: unknown }).status === "number"
  );
}

async function handleRequest(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (path === "/" || path === "/health") {
    return jsonResponse({
      ok: true,
      service: "testing-api",
      endpoints: {
        text: "/text",
        image: "/image",
        models: "/v1/models",
        chatCompletions: "/v1/chat/completions",
        imageGenerations: "/v1/images/generations",
        messages: "/v1/messages",
        countTokens: "/v1/messages/count_tokens",
      },
      compatibility: {
        openai: {
          chatCompletions: true,
          imageGenerations: true,
          tools: true,
          streaming: true,
        },
        anthropic: {
          messages: true,
          tools: true,
          streaming: true,
          tokenCounting: true,
        },
      },
    });
  }

  if (request.method !== "GET" && request.method !== "POST") {
    return errorResponse(new Error("Method not allowed."), 405);
  }

  try {
    const body = await readJson(request);

    if (path === "/v1/models") {
      return openAIModelsResponse();
    }

    if (path === "/text") {
      const result = await generateText(textInput(body, url));
      return jsonResponse(result);
    }

    if (path === "/image") {
      const result = await generateImage(imageInput(body, url));
      return jsonResponse(result);
    }

    if (path === "/v1/chat/completions") {
      return await openAIChatResponse(body);
    }

    if (path === "/v1/messages") {
      return await anthropicMessageResponse(body);
    }

    if (path === "/v1/messages/count_tokens") {
      return anthropicTokenCountResponse(body);
    }

    if (path === "/v1/images/generations") {
      return await openAIImageResponse(body);
    }

    return errorResponse(new Error("Not found."), 404);
  } catch (error) {
    if (isRequestError(error)) {
      return path.startsWith("/v1/")
        ? openAIErrorResponse(error, error.status)
        : errorResponse(error, error.status);
    }

    return path.startsWith("/v1/")
      ? openAIErrorResponse(error)
      : errorResponse(error);
  }
}

Bun.serve({
  port,
  hostname: "0.0.0.0",
  fetch: handleRequest,
  error(error) {
    return errorResponse(error);
  },
});

console.log(`API server listening on http://0.0.0.0:${port}`);
