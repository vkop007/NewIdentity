# testing

To install dependencies:

```bash
bun install
```

To run:

```bash
bun run index.ts
```

Custom endpoints:

```bash
curl -X POST http://localhost:8787/text \
  -H "Content-Type: application/json" \
  -d '{"prompt":"write one line about Azure"}'
```

```bash
curl -X POST http://localhost:8787/image \
  -H "Content-Type: application/json" \
  -d '{"prompt":"create a clean product image"}'
```

OpenAI-compatible endpoints:

```bash
curl http://localhost:8787/v1/models
```

```bash
curl -X POST http://localhost:8787/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "claudeOpus48",
    "messages": [
      { "role": "user", "content": "say hello in one line" }
    ],
    "tools": [
      {
        "type": "function",
        "function": {
          "name": "get_weather",
          "description": "Get weather for a city",
          "parameters": {
            "type": "object",
            "properties": {
              "location": { "type": "string" }
            },
            "required": ["location"]
          }
        }
      }
    ]
  }'
```

```bash
curl -X POST http://localhost:8787/v1/images/generations \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gptImage2",
    "prompt": "create a clean product image",
    "size": "1024x1024"
  }'
```

Anthropic/Claude Code-compatible endpoints:

```bash
curl -X POST http://localhost:8787/v1/messages \
  -H "Content-Type: application/json" \
  -H "Anthropic-Version: 2023-06-01" \
  -H "X-Api-Key: dummy" \
  -d '{
    "model": "claudeOpus48",
    "max_tokens": 1024,
    "tools": [
      {
        "name": "get_weather",
        "description": "Get weather for a city",
        "input_schema": {
          "type": "object",
          "properties": {
            "location": { "type": "string" }
          },
          "required": ["location"]
        }
      }
    ],
    "messages": [
      { "role": "user", "content": "What is the weather in Paris?" }
    ]
  }'
```

```bash
curl -X POST http://localhost:8787/v1/messages/count_tokens \
  -H "Content-Type: application/json" \
  -H "Anthropic-Version: 2023-06-01" \
  -H "X-Api-Key: dummy" \
  -d '{
    "model": "claudeOpus48",
    "messages": [
      { "role": "user", "content": "count this request" }
    ]
  }'
```

Claude Code settings example:

```json
{
  "$schema": "https://json.schemastore.org/claude-code-settings.json",
  "env": {
    "ANTHROPIC_BASE_URL": "https://testing-api-1780379604.azurewebsites.net",
    "ANTHROPIC_AUTH_TOKEN": "dummy",
    "ANTHROPIC_MODEL": "claudeOpus48",
    "ANTHROPIC_SMALL_FAST_MODEL": "claudeOpus48",
    "API_TIMEOUT_MS": "600000"
  }
}
```

Use the root URL for `ANTHROPIC_BASE_URL`. Do not add `/v1`; Claude Code calls `/v1/messages` itself.

OpenAI SDK/Codex-style base URL:

```bash
OPENAI_BASE_URL=https://testing-api-1780379604.azurewebsites.net/v1
OPENAI_API_KEY=dummy
```

## Azure deployment

This API uses Bun (`Bun.serve`), so do not deploy it as a normal Azure Node.js app unless you install Bun yourself. The safest Azure path is a custom container.

Build and test the container locally:

```bash
docker build -t testing-api .
docker run --rm -p 8787:8787 -e PORT=8787 testing-api
```

For Azure App Service custom container, set the container port/app setting to `8787` if needed:

```bash
WEBSITES_PORT=8787
```

The server binds to `0.0.0.0` and reads `PORT` or `WEBSITES_PORT`, so Azure can route traffic correctly.

This project was created using `bun init` in bun v1.3.6. [Bun](https://bun.com) is a fast all-in-one JavaScript runtime.
