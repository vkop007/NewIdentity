# testing

To install dependencies:

```bash
bun install
```

To run:

```bash
bun run index.ts
```

Custom endpoints:

```bash
curl -X POST http://localhost:8787/text \
  -H "Content-Type: application/json" \
  -d '{"prompt":"write one line about Azure"}'
```

```bash
curl -X POST http://localhost:8787/image \
  -H "Content-Type: application/json" \
  -d '{"prompt":"create a clean product image"}'
```

OpenAI-compatible endpoints:

```bash
curl http://localhost:8787/v1/models
```

```bash
curl -X POST http://localhost:8787/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "claudeOpus48",
    "messages": [
      { "role": "user", "content": "say hello in one line" }
    ]
  }'
```

```bash
curl -X POST http://localhost:8787/v1/images/generations \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gptImage2",
    "prompt": "create a clean product image",
    "size": "1024x1024"
  }'
```

## Azure deployment

This API uses Bun (`Bun.serve`), so do not deploy it as a normal Azure Node.js app unless you install Bun yourself. The safest Azure path is a custom container.

Build and test the container locally:

```bash
docker build -t testing-api .
docker run --rm -p 8787:8787 -e PORT=8787 testing-api
```

For Azure App Service custom container, set the container port/app setting to `8787` if needed:

```bash
WEBSITES_PORT=8787
```

The server binds to `0.0.0.0` and reads `PORT` or `WEBSITES_PORT`, so Azure can route traffic correctly.

This project was created using `bun init` in bun v1.3.6. [Bun](https://bun.com) is a fast all-in-one JavaScript runtime.
