import { generateImage, type ImageGenerationInput } from "./image.ts";
import { generateText, type TextGenerationInput } from "./text.ts";

type JsonBody = Record<string, unknown>;

const DEFAULT_PORT = 8787;
const TEXT_MODEL_ID = "claudeOpus48";
const IMAGE_MODEL_ID = "gptImage2";
const port = readPort(Bun.env.PORT ?? Bun.env.WEBSITES_PORT, DEFAULT_PORT);
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
};

function readPort(value: string | undefined, fallback: number): number {
  if (!value) {
    return fallback;
  }

  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json; charset=utf-8",
    },
  });
}

function sseResponse(events: string[]): Response {
  return new Response(events.join(""), {
    status: 200,
    headers: {
      ...corsHeaders,
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}

function errorResponse(error: unknown, status = 500): Response {
  const message = error instanceof Error ? error.message : "Unexpected server error.";
  return jsonResponse({ error: message }, status);
}

function openAIErrorResponse(error: unknown, status = 500): Response {
  const message = error instanceof Error ? error.message : "Unexpected server error.";
  return jsonResponse({
    error: {
      message,
      type: status >= 500 ? "server_error" : "invalid_request_error",
      param: null,
      code: null,
    },
  }, status);
}

async function readJson(request: Request): Promise<JsonBody> {
  if (request.method === "GET") {
    return {};
  }

  const contentType = request.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) {
    throw new RequestError("Request body must be JSON.", 415);
  }

  try {
    const body = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      throw new RequestError("JSON body must be an object.", 400);
    }

    return body as JsonBody;
  } catch (error) {
    if (error instanceof RequestError) {
      throw error;
    }

    throw new RequestError("Invalid JSON body.", 400);
  }
}

function readString(body: JsonBody, url: URL, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = body[key] ?? url.searchParams.get(key);
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }

  return undefined;
}

function textInput(body: JsonBody, url: URL): TextGenerationInput {
  const prompt = readString(body, url, ["prompt", "text", "message", "input", "q"]);
  if (!prompt) {
    throw new RequestError("Missing prompt. Send { \"prompt\": \"...\" }.", 400);
  }

  return {
    prompt,
    model: readString(body, url, ["model"]),
    outputLanguage: readString(body, url, ["outputLanguage", "output_language"]),
    searchEngine: readString(body, url, ["searchEngine", "search_engine"]),
    reasoningLevel: readString(body, url, ["reasoningLevel", "reasoning_level"]),
  };
}

function imageInput(body: JsonBody, url: URL): ImageGenerationInput {
  const prompt = readString(body, url, ["prompt", "text", "message", "input", "q"]);
  if (!prompt) {
    throw new RequestError("Missing prompt. Send { \"prompt\": \"...\" }.", 400);
  }

  return {
    prompt,
    model: readString(body, url, ["model"]),
    size: readString(body, url, ["size", "imageSize", "image_size"]),
    quality: readString(body, url, ["quality", "imageQuality", "image_quality"]),
    outputLanguage: readString(body, url, ["outputLanguage", "output_language"]),
    searchEngine: readString(body, url, ["searchEngine", "search_engine"]),
  };
}

function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.trim().length / 4));
}

function openAIId(prefix: string): string {
  const id = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `${prefix}-${id.replace(/-/g, "")}`;
}

function readMessageText(content: unknown): string {
  if (typeof content === "string") {
    return content;
  }

  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (typeof part === "string") return part;
        if (!part || typeof part !== "object") return "";

        const record = part as Record<string, unknown>;
        if (typeof record.text === "string") return record.text;
        if (typeof record.content === "string") return record.content;
        if (typeof record.input_text === "string") return record.input_text;
        return "";
      })
      .filter(Boolean)
      .join("\n");
  }

  return "";
}

function openAIChatInput(body: JsonBody): TextGenerationInput {
  const messages = body.messages;
  if (!Array.isArray(messages) || messages.length === 0) {
    throw new RequestError("Missing messages. Send OpenAI chat messages array.", 400);
  }

  const prompt = messages
    .map((message) => {
      if (!message || typeof message !== "object") return "";

      const record = message as Record<string, unknown>;
      const role = typeof record.role === "string" ? record.role : "user";
      const text = readMessageText(record.content).trim();
      return text ? `${role}: ${text}` : "";
    })
    .filter(Boolean)
    .join("\n");

  if (!prompt) {
    throw new RequestError("Messages must contain text content.", 400);
  }

  return {
    prompt,
    model: typeof body.model === "string" && body.model.trim() ? body.model.trim() : TEXT_MODEL_ID,
  };
}

function openAIImageInput(body: JsonBody): ImageGenerationInput {
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  if (!prompt) {
    throw new RequestError("Missing prompt. Send { \"prompt\": \"...\" }.", 400);
  }

  return {
    prompt,
    model: typeof body.model === "string" && body.model.trim() ? body.model.trim() : IMAGE_MODEL_ID,
    size: typeof body.size === "string" && body.size.trim() ? body.size.trim() : undefined,
    quality: typeof body.quality === "string" && body.quality.trim() ? body.quality.trim() : undefined,
  };
}

async function openAIChatResponse(body: JsonBody): Promise<Response> {
  const input = openAIChatInput(body);
  const result = await generateText(input);
  const created = Math.floor(Date.now() / 1000);
  const id = openAIId("chatcmpl");
  const model = input.model || result.model;
  const promptTokens = estimateTokens(input.prompt);
  const completionTokens = estimateTokens(result.text);

  if (body.stream === true) {
    const firstChunk = {
      id,
      object: "chat.completion.chunk",
      created,
      model,
      choices: [
        {
          index: 0,
          delta: {
            role: "assistant",
            content: result.text,
          },
          finish_reason: null,
        },
      ],
    };
    const doneChunk = {
      id,
      object: "chat.completion.chunk",
      created,
      model,
      choices: [
        {
          index: 0,
          delta: {},
          finish_reason: "stop",
        },
      ],
    };

    return sseResponse([
      `data: ${JSON.stringify(firstChunk)}\n\n`,
      `data: ${JSON.stringify(doneChunk)}\n\n`,
      "data: [DONE]\n\n",
    ]);
  }

  return jsonResponse({
    id,
    object: "chat.completion",
    created,
    model,
    choices: [
      {
        index: 0,
        message: {
          role: "assistant",
          content: result.text,
        },
        finish_reason: "stop",
      },
    ],
    usage: {
      prompt_tokens: promptTokens,
      completion_tokens: completionTokens,
      total_tokens: promptTokens + completionTokens,
    },
  });
}

function imageDataItem(image: string, responseFormat: string | undefined, revisedPrompt: string) {
  if (responseFormat === "b64_json" && image.startsWith("data:image/")) {
    return {
      b64_json: image.split(",", 2)[1] ?? image,
      revised_prompt: revisedPrompt,
    };
  }

  return {
    url: image,
    revised_prompt: revisedPrompt,
  };
}

async function openAIImageResponse(body: JsonBody): Promise<Response> {
  const input = openAIImageInput(body);
  const result = await generateImage(input);
  const created = Math.floor(Date.now() / 1000);
  const responseFormat = typeof body.response_format === "string" ? body.response_format : undefined;

  return jsonResponse({
    created,
    data: result.images.map((image) => imageDataItem(image, responseFormat, input.prompt)),
  });
}

function openAIModelsResponse(): Response {
  const created = Math.floor(Date.now() / 1000);
  return jsonResponse({
    object: "list",
    data: [
      {
        id: TEXT_MODEL_ID,
        object: "model",
        created,
        owned_by: "testing-api",
      },
      {
        id: IMAGE_MODEL_ID,
        object: "model",
        created,
        owned_by: "testing-api",
      },
    ],
  });
}

class RequestError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
    this.name = "RequestError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

function isRequestError(error: unknown): error is RequestError {
  return error instanceof RequestError || (
    Boolean(error) &&
    typeof error === "object" &&
    typeof (error as { status?: unknown }).status === "number"
  );
}

async function handleRequest(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (path === "/" || path === "/health") {
    return jsonResponse({
      ok: true,
      service: "testing-api",
      endpoints: {
        text: "/text",
        image: "/image",
        models: "/v1/models",
        chatCompletions: "/v1/chat/completions",
        imageGenerations: "/v1/images/generations",
      },
    });
  }

  if (request.method !== "GET" && request.method !== "POST") {
    return errorResponse(new Error("Method not allowed."), 405);
  }

  try {
    const body = await readJson(request);

    if (path === "/v1/models") {
      return openAIModelsResponse();
    }

    if (path === "/text") {
      const result = await generateText(textInput(body, url));
      return jsonResponse(result);
    }

    if (path === "/image") {
      const result = await generateImage(imageInput(body, url));
      return jsonResponse(result);
    }

    if (path === "/v1/chat/completions") {
      return await openAIChatResponse(body);
    }

    if (path === "/v1/images/generations") {
      return await openAIImageResponse(body);
    }

    return errorResponse(new Error("Not found."), 404);
  } catch (error) {
    if (isRequestError(error)) {
      return path.startsWith("/v1/")
        ? openAIErrorResponse(error, error.status)
        : errorResponse(error, error.status);
    }

    return path.startsWith("/v1/")
      ? openAIErrorResponse(error)
      : errorResponse(error);
  }
}

Bun.serve({
  port,
  hostname: "0.0.0.0",
  fetch: handleRequest,
  error(error) {
    return errorResponse(error);
  },
});

console.log(`API server listening on http://0.0.0.0:${port}`);
