const STUDIO_CHAT_URL = "https://studioglobal-prod-cdn-bcd3gjghfybxg9d5.z01.azurefd.net/v1/creator/chat/guest-search-online-chat";
const DEFAULT_TEXT_MODEL = "claudeOpus48";
const DEFAULT_UPSTREAM_TIMEOUT_MS = 60_000;

export type TextGenerationInput = {
  prompt: string;
  model?: string;
  outputLanguage?: string;
  searchEngine?: string;
  reasoningLevel?: string;
};

export type TextGenerationResult = {
  type: "text";
  model: string;
  guestId: string;
  text: string;
  raw: string;
};

function generateUUID(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }

  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0;
    const value = char === "x" ? random : (random & 0x3) | 0x8;
    return value.toString(16);
  });
}

function estimateInputTokens(prompt: string): number {
  return Math.max(1, Math.ceil(prompt.trim().length / 4));
}

function studioHeaders(guestId: string): HeadersInit {
  return {
    accept: "*/*",
    "accept-language": "en",
    "content-type": "application/json",
    referer: "https://www.studioglobal.ai/",
    "user-agent": "Mozilla/5.0",
    "x-studio-guest-id": guestId,
  };
}

function upstreamTimeoutMs(): number {
  const value = Bun.env.UPSTREAM_TIMEOUT_MS;
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : DEFAULT_UPSTREAM_TIMEOUT_MS;
}

function textPayload(input: Required<Pick<TextGenerationInput, "prompt" | "model" | "outputLanguage" | "searchEngine" | "reasoningLevel">>) {
  return {
    aiModel: input.model,
    description: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: input.prompt,
          },
        ],
        metadata: {
          routeMode: "search",
          appMode: "chat",
          chatMode: "search",
          modePreset: "fast",
          aiModel: input.model,
          chatUseCase: "general",
          searchSources: [],
          searchEngine: input.searchEngine,
          reasoningLevel: input.reasoningLevel,
          modeSwitchRouteMode: "search",
        },
        attachFiles: [],
      },
    ],
    chatContext: "chat",
    inputTokens: estimateInputTokens(input.prompt),
    outputLanguage: input.outputLanguage,
    brandVoice: "",
    searchEngine: input.searchEngine,
    reasoningLevel: input.reasoningLevel,
  };
}

async function readStream(response: Response): Promise<string> {
  const reader = response.body?.getReader();
  if (!reader) {
    return response.text();
  }

  const decoder = new TextDecoder();
  let fullResponse = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    fullResponse += decoder.decode(value, { stream: true });
  }

  fullResponse += decoder.decode();
  return fullResponse;
}

function collectStrings(value: unknown, output: string[]): void {
  if (typeof value === "string") {
    output.push(value);
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectStrings(item, output);
    }
    return;
  }

  if (!value || typeof value !== "object") {
    return;
  }

  const record = value as Record<string, unknown>;
  for (const key of ["text", "content", "message", "answer", "output", "delta"]) {
    collectStrings(record[key], output);
  }
}

function extractText(raw: string): string {
  const chunks: string[] = [];

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed === "[DONE]") continue;

    const payload = trimmed.startsWith("data:")
      ? trimmed.slice(5).trim()
      : trimmed;
    if (!payload || payload === "[DONE]") continue;

    try {
      const parsed = JSON.parse(payload);
      collectStrings(parsed, chunks);
    } catch {
      if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) {
        chunks.push(payload);
      }
    }
  }

  const text = chunks.join("").trim();
  return text || raw.trim();
}

export async function generateText(input: TextGenerationInput): Promise<TextGenerationResult> {
  const prompt = input.prompt.trim();
  if (!prompt) {
    throw new Error("Prompt is required.");
  }

  const model = input.model?.trim() || DEFAULT_TEXT_MODEL;
  const guestId = generateUUID();
  const response = await fetch(STUDIO_CHAT_URL, {
    method: "POST",
    headers: studioHeaders(guestId),
    signal: AbortSignal.timeout(upstreamTimeoutMs()),
    body: JSON.stringify(textPayload({
      prompt,
      model,
      outputLanguage: input.outputLanguage?.trim() || "Default",
      searchEngine: input.searchEngine?.trim() || "perplexity",
      reasoningLevel: input.reasoningLevel?.trim() || "low",
    })),
  });

  const raw = await readStream(response);
  if (!response.ok) {
    throw new Error(`Text API error: ${response.status} ${response.statusText}${raw ? ` - ${raw}` : ""}`);
  }

  return {
    type: "text",
    model,
    guestId,
    text: extractText(raw),
    raw,
  };
}
